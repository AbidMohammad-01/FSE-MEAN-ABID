import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { CartService } from '../services/cart.service';

import { ComparisonComponent } from './comparison.component';

describe('ComparisonComponent', () => {
  let component: ComparisonComponent;
  let cart =CartService
  let fixture: ComponentFixture<ComparisonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ComparisonComponent],
      imports :[HttpClientTestingModule]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ComparisonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call removeItem..', ()=>{
    // component.cartItem=[{}]
    // let service = fixture.debugElement.injector.get(cartService);
    // spyOn(service, 'deleteCart').and.callFake(()=>{
    //   return of({
    //     statusCode:200
    //   })
    // })
    let spy =spyOn(component, 'removeItem').and.callThrough();
    component.removeItem(2);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call ngOnInit error..', ()=>{
    // component.cartItem=[{}]
    let service = fixture.debugElement.injector.get(cart);
    spyOn(service, 'showCompare').and.returnValue(throwError({status:422}))
     
    let spy =spyOn(component, 'ngOnInit').and.callThrough();
    component.ngOnInit();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call ngOnInit error..', ()=>{
    // component.cartItem=[{}]
    let service = fixture.debugElement.injector.get(cart);
    spyOn(service, 'showCompare').and.callFake(()=>{
        return of({
          payload:{}
        })
      })
    let spy =spyOn(component, 'ngOnInit').and.callThrough();
    component.ngOnInit();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call removeItem error..', ()=>{
    // component.cartItem=[{}]
    let service = fixture.debugElement.injector.get(cart);
    spyOn(service, 'deleteCompare').and.returnValue(throwError({status:422}))
     
    let spy =spyOn(component, 'removeItem').and.callThrough();
    component.removeItem(2);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call removeItem error..', ()=>{
    component.compareMob=[]
    let service = fixture.debugElement.injector.get(cart);
    spyOn(service, 'deleteCompare').and.callFake(()=>{
        return of({
          payload:{}
        })
      })
    let spy =spyOn(component, 'removeItem').and.callThrough();
    component.removeItem(2);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

});
