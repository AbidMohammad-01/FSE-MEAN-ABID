import { HttpClient } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { NgToastService } from 'ng-angular-popup';
import { Movie } from '../models/movie';
import { CartService } from '../services/cart.service';
import { MoviesService } from '../services/movies.service';
import { UserregisterService } from '../services/userregister.service';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrl: './movie.component.css'
})
export class MovieComponent {
  constructor(public movie:MoviesService,public router:Router,private cart:CartService,public http:HttpClient,public activate:ActivatedRoute){
   
  }
  selectedProduct:Movie
ticketQuantity:number
ticket:any
price:Number
toast = inject(NgToastService)
displayingSeatnum:any
// title:String
// theatre:String
selectedSeats:[]

    ngOnInit(): void {
      let title=this.activate.snapshot.paramMap.get('title'); //id of selected mobile
      //displaying the selected product using method in service
      this.movie.displayMovieById(title).subscribe(
        (s)=>{
          this.selectedProduct=s.payload[0];
    
        },
      (error)=>{console.log("Error in displaying",error)
      }    
      )
    }
      
    bookTickets(theatre:string,title:string){
      this.movie.bookMovieTickets(theatre,title,this.ticketQuantity,this.selectedSeats).subscribe(
        (res)=>{
          this.ticket=res.payload
          this.displayingSeatnum=res.payload.seatnum.join(',')
console.log('Messgae',res.payload.seatnum)
         if(res.message==="Tickets booked") {this.toast.success({
            detail:'Tickets Booked',
            summary:`tickets for ${title} booked successfully`,
            position:'topCenter',
            duration:3000
          })}
         
        },
        (error)=>{console.error();
        }
      )

    }
    calculatePrice(seats:any,price:any): number {
      
      return parseInt(seats) * parseInt(price);
    }
  
}
