import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { of, throwError } from 'rxjs';
import { UserregisterService } from '../services/userregister.service';

import { RegisterComponent } from './register.component';

describe('RegisterComponent', () => {
  let component: RegisterComponent;
  let userReg=UserregisterService;
  let fixture: ComponentFixture<RegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RegisterComponent],
      imports :[HttpClientTestingModule, FormsModule, ReactiveFormsModule]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  
  it('should call onSubmitUser error..', ()=>{
    let service = fixture.debugElement.injector.get(userReg);
    spyOn(service, 'createUser').and.returnValue(throwError({status:422}))
     
    let spy =spyOn(component, 'onSubmitUser').and.callThrough();
    component.onSubmitUser();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call onSubmitUser error..', ()=>{
    let service = fixture.debugElement.injector.get(userReg);
    spyOn(service, 'createUser').and.callFake(()=>{
        return of({
          message:'succesfully registered'
        })
      })
    let spy =spyOn(component, 'onSubmitUser').and.callThrough();
    component.onSubmitUser();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call onSubmitUser error..', ()=>{
    let service = fixture.debugElement.injector.get(userReg);
    spyOn(service, 'createUser').and.callFake(()=>{
        return of({
          message:''
        })
      })
    let spy =spyOn(component, 'onSubmitUser').and.callThrough();
    component.onSubmitUser();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })
});
