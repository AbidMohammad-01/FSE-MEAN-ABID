import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { of, throwError } from 'rxjs';
import { AdminService } from '../services/admin.service';

import { AdminhomeComponent } from './adminhome.component';

describe('AdminhomeComponent', () => {
  let component: AdminhomeComponent;
  let movie =AdminService;
  let fixture: ComponentFixture<AdminhomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AdminhomeComponent],
      imports :[HttpClientTestingModule, ReactiveFormsModule, FormsModule]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AdminhomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should call getTitle..', ()=>{
    let spy =spyOn(component, 'getTitle').and.callThrough();
    component.getTitle('movie');
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })
  it('should call selectMovie..', ()=>{
    let spy =spyOn(component, 'selectMovie').and.callThrough();
    component.selectMovie(2); 
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call updateStatus..', ()=>{
    let service = fixture.debugElement.injector.get(movie);
    spyOn(service, 'updateTicketStatus').and.callFake(()=>{
        return of({
          message:'Status Updated'
        })
      })
    let spy =spyOn(component, 'updateStatus').and.callThrough();
    component.updateStatus(); 
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call updateStatus..', ()=>{
    let service = fixture.debugElement.injector.get(movie);
    spyOn(service, 'updateTicketStatus').and.returnValue(throwError({status:422}))
    let spy =spyOn(component, 'updateStatus').and.callThrough();
    component.updateStatus(); 
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call send error..', ()=>{
    // component.cartItem=[{}]
    let service = fixture.debugElement.injector.get(movie);
    spyOn(service, 'addMovie').and.returnValue(throwError({status:422}))
     
    let spy =spyOn(component, 'send').and.callThrough();
    component.send();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call send ..', ()=>{
    let service = fixture.debugElement.injector.get(movie);
    spyOn(service, 'addMovie').and.callFake(()=>{
        return of({
          payload:{}
        })
      })
    let spy =spyOn(component, 'send').and.callThrough();
    component.send();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call deleteMovie..', ()=>{
    component.movies=[]
    let service = fixture.debugElement.injector.get(movie);
    spyOn(service, 'deleteMovie').and.callFake(()=>{
        return of({
          payload:{}
        })
      })
    let spy =spyOn(component, 'deleteMovie').and.callThrough();
    component.deleteMovie('movie',2);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })
  it('should call deleteMovie..', ()=>{
    component.movies=[]
    let service = fixture.debugElement.injector.get(movie);
    spyOn(service, 'deleteMovie').and.returnValue(throwError({status:422}))
     
    let spy =spyOn(component, 'deleteMovie').and.callThrough();
    component.deleteMovie('movie',2);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })
 
});
