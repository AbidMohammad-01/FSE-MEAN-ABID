import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { ProductListService } from './productlist.service';

describe('ProductListService', () => {
  let service: ProductListService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports :[HttpClientTestingModule]
    });
    service = TestBed.inject(ProductListService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call displayProducts..', ()=>{
    let spy =spyOn(service, 'displayProducts').and.callThrough();
    service.displayProducts();
    expect(spy).toHaveBeenCalled();
  })

  it('should call getProductById..', ()=>{
    let id:any
    let spy =spyOn(service, 'getProductById').and.callThrough();
    service.getProductById(id);
    expect(spy).toHaveBeenCalled();
  })

  it('should call allProducts..', ()=>{
    let spy =spyOn(service, 'allProducts').and.callThrough();
    service.allProducts();
    expect(spy).toHaveBeenCalled();
  })
});
